<?php
/**
 * Created by PhpStorm.
 * User: kiavash
 * Date: 6/5/2019
 * Time: 12:00 PM
 */
session_start();
include_once "functions.php";
if(!isset($_SESSION['username']) || !isset($_GET['user_id'])){
    header("location: dex.php");
}
@$user_id_get = $_GET['user_id'];
@$user_id_session = $_SESSION['user_id'];
if($user_id_get != $user_id_session){
    header("location: dex.php");
}

if($_SERVER['REQUEST_METHOD'] == "POST"){
    $old_psw = $_POST['old_psw'] ? $_POST['old_psw'] : null;
    $new_psw1 = $_POST['new_psw1'] ? $_POST['new_psw1'] : null;
    $new_psw2 = $_POST['new_psw2'] ? $_POST['new_psw2'] : null;
    if(is_null($old_psw) || is_null($new_psw1) || is_null($new_psw2)) {
        $answer = "اطلاعات ارسال شده متبر نیستند";
    } elseif (!check_psw($user_id_get,$old_psw)){
        $answer = "کلمه عبور قبلی صحیح نیست";
    } elseif ($old_psw === $new_psw1) {
        $answer = "کلمه عبور جدید برابر کلمه قبلی وارد شده است";
    } elseif ($new_psw1 != $new_psw2){
        $answer = "کلمه عبور های جدید وارد شده یکسان نیستند";
    } elseif (change_psw($user_id_get,$new_psw1)){
        $answer = "تغییر کلمه عبور با موفقیت انجام شد";
        header("location: change_psw.php");
    } else {
        $answer = "خطا در تغییر کلمه عبور";
    }
}

?>

<!DOCTYPE html>
<html lang="fa">
    <?php include "head.php"; ?>
<body>
    <?php include "header.php"; ?>
    <div class="div_answer">
        <h4 id="h4_answer"><?php echo $answer ?></h4>
    </div>
    <div class="cont01">
        <form method="post">
            <label for="old_psw" class="label_style">کلمه عبور فعلی</label>
            <input type="password" class="Input_style" name="old_psw" required/><br/>
            <label for="new_psw1" class="label_style">کلمه عبور جدید</label>
            <input type="password" class="Input_style" name="new_psw1" required/><br/>
            <label for="new_psw2" class="label_style">تکرار کلمه عبور جدید</label>
            <input type="password" class="Input_style" name="new_psw2" required/><br/>
            <button type="submit" class="btn">ذخیره</button>
            <button type="button" class="btn" onclick="window.location.href='user_panel.php'">انصراف</button>
        </form>
    </div>
</body>
