<?php
/**
 * Created by PhpStorm.
 * User: kiavash
 * Date: 5/3/2019
 * Time: 11:35 PM
 */
session_start();
include_once "functions.php";
include_once "../function/p_date.php";
$result = '';
if($_SERVER['REQUEST_METHOD'] == "GET") {
    $rows = 10;
    $q = "";
    $j = 0;
    if(isset($_GET['key'])) {
        if ($_GET['key'] == 1) { //all ads
            $q = "SELECT `ad`.*, CONCAT(`city`.`name`,' / ',`city`.`province`) AS `city`, TIMESTAMP(`ad`.`approved`) AS `tss`,
                CONCAT(`user`.`fname`,' ',`user`.`lname`) as user
                FROM `ad` LEFT JOIN `city` ON `ad`.`city_id` = `city`.`id` LEFT JOIN `user` ON `user`.`id` = `ad`.`user_id`
                ORDER BY `ad`.`date`";
        }
        if ($_GET['key'] == 2) { //active ads
            $q = "SELECT `ad`.*, CONCAT(`city`.`name`,' / ',`city`.`province`) AS `city`,
                CONCAT(`user`.`fname`,' ',`user`.`lname`) as user
                FROM `ad` LEFT JOIN `city` ON `ad`.`city_id` = `city`.`id` LEFT JOIN `user` ON `user`.`id` = `ad`.`user_id`
                WHERE ISNULL(`ad`.`finished`) AND ISNULL(`ad`.`rejected`) AND !ISNULL(`ad`.`approved`) 
                ORDER BY `ad`.`date`";
        }
        if ($_GET['key'] == 3) { //finsihed ads
            $q = "SELECT `ad`.*, CONCAT(`city`.`name`,' / ',`city`.`province`) AS `city`,
                CONCAT(`user`.`fname`,' ',`user`.`lname`) as user
                FROM `ad` LEFT JOIN `city` ON `ad`.`city_id` = `city`.`id` LEFT JOIN `user` ON `user`.`id` = `ad`.`user_id`
                WHERE !ISNULL(`ad`.`finished`) 
                ORDER BY `ad`.`date`";
        }
        if ($_GET['key'] == 4) { //rejected ads
            $q = "SELECT `ad`.*, CONCAT(`city`.`name`,' / ',`city`.`province`) AS `city`,
                CONCAT(`user`.`fname`,' ',`user`.`lname`) as user
                FROM `ad` LEFT JOIN `city` ON `ad`.`city_id` = `city`.`id` LEFT JOIN `user` ON `user`.`id` = `ad`.`user_id`
                WHERE !ISNULL(`ad`.`rejected`) 
                ORDER BY `ad`.`date`";
        }
        if ($_GET['key'] == 5) { //promoted ads
            $q = ""; // should check from payment table
        }
        if ($_GET['key'] == 6) { //new ads
            $q = "SELECT `ad`.*, CONCAT(`city`.`name`,' / ',`city`.`province`) AS `city`,
                CONCAT(`user`.`fname`,' ',`user`.`lname`) as user
                FROM `ad` LEFT JOIN `city` ON `ad`.`city_id` = `city`.`id` LEFT JOIN `user` ON `user`.`id` = `ad`.`user_id`
                WHERE ISNULL(`ad`.`finished`) AND ISNULL(`ad`.`rejected`) AND ISNULL(`ad`.`approved`) 
                ORDER BY `ad`.`date` ASC";
        }
        $conn = jooyande();
        $r = $conn->query($q);
        $result_data = $r->fetch_all(MYSQLI_ASSOC);
        $_SESSION['ad_list'] = $result_data;
        if(!isset($_SESSION['pointer'])) {
            $_SESSION['pointer'] = 0;
        }

        $links = ""; //to determine how may links are required if records are more than 20.
        for($i = 1;$i <= ceil($r->num_rows / $rows); $i++){
        $links .= "<a href='#' onclick='next_ads($i)'>$i</a>";
        }
        $j = 0;
    } elseif (isset($_GET['group'])){
        $result_data = $_SESSION['ad_list'];
        $j = $_GET['group'] - 1;
        $links = null;
    }

    for($i = ($j * $rows); $i < min(count($result_data), ($j + 1) * $rows); $i++){
        $st = "";
        $st_date = "";
        if($result_data[$i]['finished']){
            $st = "کنسل/منقضی";
            $st_date = p_date_mysql($result_data[$i]['finished']);
        } else if ($result_data[$i]['approved']) {
                $st = "فعال";
                $st_date = p_date_mysql($result_data[$i]['approved']);
            } else if ($result_data[$i]['rejected']){
                $st = "مردود";
                $st_date = p_date_mysql($result_data[$i]['rejected']);
            } else {
            $st = "منتظر بررسی";
            $st_date = "";
        }
        $result .= "<TR ondblclick='go_to_ad($i)'>
                        <td>" . ($i+1) . "</td>
                        <td>" . $result_data[$i]['desc'] . "</td>
                        <td>" . $result_data[$i]['user'] . "</td>
                        <td>" . $result_data[$i]['city'] . "</td>
                        <td>$st</td>
                        <td>$st_date</td>
                    </TR>";
    }
    if($conn) {
        $conn->close();
    }
    $final_result2 = array("p"=>$links, "thead"=>$result, "total"=>count($result_data));
    $final_result = json_encode($final_result2);
    echo $final_result;
}