<?php
/**
 * Created by PhpStorm.
 * User: kiavash
 * Date: 5/3/2019
 * Time: 5:03 PM
 */
session_start();
include_once "functions.php";
include_once "../function/p_date.php";
if(!isset($_SESSION['admin'])){
    header("location: admin_signin.php");
} else {
    $admin = $_SESSION['admin']['fname'] . " " . $_SESSION['admin']['lname'];
}
if(isset($_SESSION['pointer'])){
    if($_SERVER['REQUEST_METHOD'] == "GET") {
        if($_GET['q'] == 'next') {
            if($_SESSION['pointer'] < count($_SESSION['ad_list']) -1 ) {
                $_SESSION['pointer']++;
            }
        } elseif ($_GET['q'] == 'prev') {
            if($_SESSION['pointer'] > 0) {
                $_SESSION['pointer']--;
            }
        } elseif ($_GET['q'] == 'go'){
            $_SESSION['pointer'] = $_GET['r'];
        }
        if($_SESSION['pointer'] >= count($_SESSION['ad_list']) -1 ) {
            $allow_next = false;
        } else{
            $allow_next = true;
        }
        if($_SESSION['pointer'] <= 0) {
            $allow_prev = false;
        } else{
            $allow_prev = true;
        }
    }
    $i = $_SESSION['pointer'];
    $j = count($_SESSION['ad_list']);
} else {
    $i = 0;
    $j = 0 ;
}
//echo $_SESSION['pointer'] . "<br/>";
?>

<!DOCTYPE html>
<html lang="fa">
    <head>
        <meta charset="UTF-8"/>
        <title>پنل مدیریت سایت جوینده</title>
        <link rel="stylesheet" href="style.css"/>
<!--        <link rel="stylesheet" href="kia_option.css"/>-->
    </head>
    <body>
    <div class="cont01">
        <p id="result"><a href="admin_panel.php"><?php echo $admin; ?></a></p>
    </div>
    <div class="cont01">
        <div class="right_justify">
            <label class="caption">کاربر</label>
            <label><?php echo (isset($_SESSION['ad_list'])) ? $_SESSION['ad_list'][$i]['user'] : "---"; ?></label><br/>
            <label class="caption">شهر</label>
            <label><?php echo (isset($_SESSION['ad_list'])) ? $_SESSION['ad_list'][$i]['city'] : "---"; ?></label><br/>
            <label class="caption">شرح آگهی</label>
            <label><?php echo (isset($_SESSION['ad_list'])) ? $_SESSION['ad_list'][$i]['desc'] : "---"; ?></label><br/>
            <label class="caption">توضیحات</label>
            <label><?php echo (isset($_SESSION['ad_list'])) ? $_SESSION['ad_list'][$i]['note'] : "---"; ?></label><br/>
            <label class="caption">قیمت</label>
            <label><?php echo (isset($_SESSION['ad_list'])) ? $_SESSION['ad_list'][$i]['price'] : "---"; ?></label><br/>
            <label class="caption">وضعیت</label>
            <label><?php echo (isset($_SESSION['ad_list'])) ? $_SESSION['ad_list'][$i]['status'] : "---"; ?></label><br/>
            <label class="caption">تلفن</label>
            <label><?php echo (isset($_SESSION['ad_list'])) ? $_SESSION['ad_list'][$i]['phone'] : "---"; ?></label><br/>
            <label class="caption">ساعت تماس</label>
            <label><?php echo (isset($_SESSION['ad_list'])) ? $_SESSION['ad_list'][$i]['call_time'] : "---"; ?></label><br/>
            <label class="caption">تاریخ ثبت</label>
            <label><?php echo (isset($_SESSION['ad_list'])) ? p_date_mysql($_SESSION['ad_list'][$i]['date']) : "---"; ?></label><br/>
            <label class="caption">تاریخ تایید</label>
            <label id="approved"><?php echo (isset($_SESSION['ad_list'])) ? p_date_mysql($_SESSION['ad_list'][$i]['approved']) : "---"; ?></label><br/>
            <label class="caption">تاریخ رد</label>
            <label id="rejected"><?php echo (isset($_SESSION['ad_list'])) ? p_date_mysql($_SESSION['ad_list'][$i]['rejected']) : "---"; ?></label><br/>
            <label class="caption">تاریخ کنسل</label>
            <label><?php echo (isset($_SESSION['ad_list'])) ? p_date_mysql($_SESSION['ad_list'][$i]['finished']) : "---"; ?></label><br/>
            <label class="caption">اعتبار ویژه به روز</label>
            <label><?php echo (isset($_SESSION['ad_list'])) ? $_SESSION['ad_list'][$i]['user'] : "---"; ?></label><br/>
        </div><br/>
        <label><?php echo "ردیف " . ($i + 1) . " از " . $j ?></label><br/>
        <button class="btn" onclick="next_ad()" <?php echo ($allow_next) ? "" : "disabled"; ?> >بعدی</button>
        <button class="btn" onclick="prev_ad()" <?php echo ($allow_prev) ? "" : "disabled"; ?> >قبلی</button><br/>
        <button class="btn" onclick="verify_ad('approve')">تایید</button>
        <button class="btn" onclick="verify_ad('reject')">رد</button>
    </div>
    <script src="app.js"></script>
    </body>
</html>
