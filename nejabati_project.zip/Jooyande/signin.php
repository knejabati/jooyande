<?php
    session_start();
    require_once "../function/kia_func.php";
    include_once "functions.php";
if(isset($_SESSION['username'])){
        header("location: dex.php");
    }
    $username_err = $psw_err = $signin_err = "";
    if($_SERVER['REQUEST_METHOD'] == 'POST'){
        $username = inp_validate($_POST['username']);
        $psw = inp_validate($_POST['psw']);
        $remember = $_POST['remember'];
        if(empty($username)){
            $username_err = "لطفا نام کاربری را وارد نمایید.";
        } else {
            if (empty($psw)) {
                $psw_err = "لطفا کلمه عبود را وارد نمایید.";
            } else {
                $conn = jooyande();
                $q = "select * from user where trim(email) = '$username'";
                $r = $conn->query($q);
                if ($data = $r->fetch_assoc()){
                    if(password_verify($psw,$data['psw'])) {
                        set_user_session($data);
                        if($remember == "on") {
                            setcookie('username',$username,time() + 2592000,'/'); //30days
                        }
                        header("location: dex.php");
                    } else{
                        $signin_err = "کلمه عبور صحیح نیست";
                    }
                } else {
                    $signin_err = "نام کاربری صحیح نیست";
                }
            }
        }
    }
?>

<!DOCTYPE html>
<html lang="fa">
    <?php include "head.php"; ?>
<body>
    <?php include "header.php"; ?>
    <div class="div_signin cont01">
        <form method="post" onsubmit="return check_signin()">
            <label for="username" class="label_style">نام کاربری</label>
            <input type="text" id="username" name="username" class="Input_style" required placeholder="لطفا آدرس ایمیل خود را وارد نمایید."/><br/>
            <label for="psw" class="label_style">کلمه عبور</label>
            <input type="password" id="psw" name="psw" class="Input_style" required placeholder="لطفا کلمه عبور را وارد نمایید."/><br/>
            <input type="checkbox" name = "remember" id="remember"/>
                <label id="remember" for="remember">مرا با خاطر داشته باش</label><br/>
            <button type="submit" id="btn_signin" class="btn">ورود</button>
        </form>
        <button id="btn_signup" class="btn" onclick="location.href='signup.php'">ثبت نام</button>
        <p><?php echo $username_err . $psw_err . $signin_err ?></p>
    </div>
</body>
</html>