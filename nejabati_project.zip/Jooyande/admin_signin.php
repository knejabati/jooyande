<?php
/**
 * Created by PhpStorm.
 * User: kiavash
 * Date: 5/7/2019
 * Time: 11:00 PM
 */
session_start();
if(isset($_SESSION['admin'])){
    header("location: admin_panel.php");
}
include_once "functions.php";
$answer = "";
if($_SERVER['REQUEST_METHOD'] == 'POST'){
   if(!isset($_POST['username'])){
       $answer = "لطفا نام کابری را وارد نمایید";
   } elseif(!isset($_POST['username'])){
       $answer = "لطفا کلمه عبور را وارد نمایید";
   } else{
       $un = $_POST['username'];
       $psw = $_POST['psw'];
       $conn = jooyande();
       $q = "SELECT `username`,`fname`,`lname` FROM `admin` WHERE `username` = '$un' AND `psw` = '$psw'";
       $r = $conn->query($q);
       if($r->num_rows == 1){
           $admin = $r->fetch_assoc();
           $_SESSION['admin'] = $admin;
           header("location: admin_panel.php");
       } else {
           $answer = "نام کاربری یا کلمه عبور صحیح نیست";
       }
   }
}

?>

<!DOCTYPE html>
<html>
    <head>
        <title>پنل مدیریت سایت جوینده</title>
        <meta charset="UTF-8"/>
        <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
        <link rel="stylesheet" href="style.css"/>
    </head>
    <body>
    <div class="cont01">
        <p> به صفحه ورود مخصوص مدیران سیستم خوش آمدید</p>
        <p>لطفا نام کاربری و کلمه عبور خود را وارد نمایید</p>
    </div>
    <div class="cont01">
        <div class="admin_signin">
            <form action="" method="post">
                <label for="username" class="label_style">نام کاربری</label>
                <input type="text" class="Input_style" id="username" name="username" placeholder="نام کابری خود را وارد نمایید" required/><br/>
                <label for="psw" class="label_style">کلمه عبور</label>
                <input type="password" class="Input_style" id="psw" name="psw" placeholder="لطفا کلمه عبور را وارد نمایید" required/><br/>
                <button type="submit" class="btn">ورود به سیستم</button>
                <p><?php echo $answer; ?></p>
            </form>
        </div>
    </div>
    </body>
</html>
