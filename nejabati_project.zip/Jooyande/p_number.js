function p_number(t_digit){
    if(isNaN(t_digit)){return "";}
    let c = Math.ceil(t_digit.length / 3);
    if(c > 5){return "Numeric Overflow!";}

    res = "";
    let vCheck = vLength = 0;
    for(j = c; j >= 1; j--){
        d = t_digit.substr(Math.max(0, t_digit.length - (j * 3)), Math.min(t_digit.length - ((j -1) * 3), 3));
        vLength += d.length;
        switch (true){
            case (j == 5 && Number(d) > 0) : pre = " تیلیارد"; break;
            case (j == 4 && Number(d) > 0) : pre = " میلیارد"; break;
            case (j == 3 && Number(d) > 0) : pre = " میلیون"; break;
            case (j == 2 && Number(d) > 0) : pre = " هزار"; break;
            default: pre = ""; break;
        }
        if (j > 1 && Number(t_digit.substr(vLength, 3)) > 0){
            vCheck = 1;
        } else {
            vCheck = 0;
        }
        res += ((j == 2 && digit_m(d) == "یک") ? "" : digit_m(d)) + pre + ((vCheck == 1) ? " و " : " ");
    }
    return res;

    function digit_m(t_digit){
        var p_num = "";
        for(i = t_digit.length; i >= 1 ; i--){
            new_num = ""
            n = t_digit.substr(t_digit.length - i, 1);
            if(i == 2 && n == "1"){
                n=t_digit.substr(t_digit.length - i, 2);
            }
            p_num += ((p_num != "" && digit(n,i) != "") ? " و " : "") + digit(n,i);
            if(n.length == 2){break;}
        }
        return p_num;
    }

    function digit(n,i){
        switch (n + i){
            case "01": p_digit = ""; break;
            case "11": p_digit = "یک"; break;
            case "21": p_digit = "دو"; break;
            case "31": p_digit = "سه"; break;
            case "41": p_digit = "چهار"; break;
            case "51": p_digit = "پنج"; break;
            case "61": p_digit = "شش"; break;
            case "71": p_digit = "هفت"; break;
            case "81": p_digit = "هشت"; break;
            case "91": p_digit = "نه"; break;
            case "02": p_digit = ""; break;
            case "102": p_digit = "ده"; break;
            case "112": p_digit = "یازده"; break;
            case "122": p_digit = "دوازده"; break;
            case "132": p_digit = "سیزده"; break;
            case "142": p_digit = "چهارده"; break;
            case "152": p_digit = "پانزده"; break;
            case "162": p_digit = "شانزده"; break;
            case "172": p_digit = "هفده"; break;
            case "182": p_digit = "هجده"; break;
            case "192": p_digit = "نوزده"; break;
            case "22": p_digit = "بیست"; break;
            case "32": p_digit = "سی"; break;
            case "42": p_digit = "چهل"; break;
            case "52": p_digit = "پنجاه"; break;
            case "62": p_digit = "شصت"; break;
            case "72": p_digit = "هفتاد"; break;
            case "82": p_digit = "هشتاد"; break;
            case "92": p_digit = "نود"; break;
            case "03": p_digit = ""; break;
            case "13": p_digit = "صد"; break;
            case "23": p_digit = "دویست"; break;
            case "33": p_digit = "سیصد"; break;
            case "43": p_digit = "چهارصد"; break;
            case "53": p_digit = "پانصد"; break;
            case "63": p_digit = "ششصد"; break;
            case "73": p_digit = "هفتصد"; break;
            case "83": p_digit = "هشتصد"; break;
            case "93": p_digit = "نهصد"; break;
        }
        return p_digit;
    }
}