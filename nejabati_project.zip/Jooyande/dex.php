<?php
session_start();
include_once "functions.php";
$filter_province = '';
$ar_province = '[';
$conn = jooyande();

$q = "SELECT DISTINCT `province` FROM `city` WHERE `city`.`id` IN (SELECT DISTINCT `city_id` FROM `ad` WHERE NOT ISNULL(`approved`) AND ISNULL(`finished`))";
$r = $conn->query($q);
if($r->num_rows > 0) {
    while ($data = $r->fetch_assoc()) {
        $filter_province .= "<div onclick='f_select(this), get_city(this)'>" . $data['province'] . "</div>";
        $ar_province .= '\'' . $data['province'] . '\',';
    }
    $ar_province .= '];';
}
if(isset($_GET['exit'])){
    if($_GET['exit'] == 'true'){
        unset($_SESSION['username']);
        unset($_SESSION['nickname']);
        unset($_SESSION['phone']);
        unset($_SESSION['user_id']);
        if (isset($_COOKIE['username'])) {
            setcookie('username','any',-1,'/');
            unset($username);
            unset($_COOKIE['username']);
        }
    }
}
?>

<!DOCTYPE html>
<html lang="fa">
    <?php include "head.php"; ?>
<body>
    <?php include "header.php"; ?>
    <div class="div_add_ad cont01">
        <a href="add_ad.php" <?php echo (isset($_SESSION['username'])) ? '' : 'onclick="return adding()"'?>>ثبت رایگان آگهی</a>
    </div>
    <div class="div_search cont01">
        <h3 id="rr">جستجوی آگهی</h3>
            <label for="select_province" class="label_style">انتخاب استان</label>
            <div class="kia_op_01" onclick="ff(this)">
                <input type="text" name="select_provice" id="select_province" class="Input_style" oninput="filter_op(this,ar_province)" placeholder="نام استان را انتخاب نمایید" autocomplete="off"/>
                <div class="kia_op_list">
                    <?php echo $filter_province; ?>
                </div>
            </div><br/>
        <form action="result_overal.php" method="get" onsubmit="return check_search()">
            <label for="select_city" class="label_style">انتخاب شهر</label>
            <div class="kia_op_01" onclick="ff(this)">
                <input type="text" name="city" id="select_city" class="Input_style" oninput="filter_op(this,ar_city)" placeholder="نام شهر را انتخاب نمایید" autocomplete="off"/>
                <div class="kia_op_list" id="div_get_city">
<!--                    code will be added here by javascript after selecting prvince-->
                </div>
            </div><br/>
            <label for="inp_keyword" class="label_style">انتخاب کلمات کلیدی</label>
            <input  type ="text" class="input_keyword Input_style" name="keyword" id="inp_keyword"/>
            <div class="div_temp">
                <button type="submit" id="btn_search" class="btn">جستجو</button>
                <button type="reset" id="btn_search" class="btn">انصراف</button>
            </div>
        </form>
    </div>
    <script>
        var ar_province = <?php echo $ar_province; ?>
    </script>
    <script src="app.js"></script>
    <script src="kia_option.js"></script>
</body>
</html>