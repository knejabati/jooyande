<?php
/**
 * Created by PhpStorm.
 * User: kiavash
 * Date: 6/6/2019
 * Time: 1:36 AM
 */
session_start();
if (!isset($_SESSION['username'])){
    header("location: dex.php");
}
include_once "functions.php";
if($_SERVER['REQUEST_METHOD'] == "POST") {
    $salesplan_id = isset($_POST['salesplan_id']) ? $_POST['salesplan_id'] : null;
    $user_id = isset($_POST['user_id']) ? $_POST['user_id'] : null;
    $ad_id = isset($_POST['ad_id']) ? $_POST['ad_id'] : null;
    $url = isset($_POST['url']) ? $_POST['url'] : null;
    $result = $answer = 0;
    if (is_null($salesplan_id) || is_null($user_id) || is_null($ad_id) || is_null($url)) {
        header("location:" . $url);
    }
    if (!isset($conn)) {
        $conn = jooyande();
    }
    $q = "SELECT `price` FROM `salesprice` WHERE `salesplan_id`='$salesplan_id' ORDER BY `date` DESC LIMIT 1";
    //TODO check if the ad has an active plan or not. if has, prevent new sale.
    $r = $conn->query($q);
    if ($r->num_rows == 1){
        $d = $r->fetch_assoc();
        $price = $d['price'];
        $q = "INSERT INTO `sales` (`ad_id`,`salesplan_id`,`date`,`price`) VALUES ('$ad_id', '$salesplan_id', now(), '$price')";
        $conn->query($q);
        if($conn->affected_rows == 1){
            $result = 1;
        } else {
            $result = -1; // can't insert into sales table.
        }
    } else {
        $result = -2; // the plan is not exists.
    }
    $_SESSION['url'] = $url;
    $_SESSION['result'] = $result;
    header("location: commit_purchase.php");
}
if($_SERVER['REQUEST_METHOD'] == "GET") {
    if(isset($_SESSION['url'])){
        $url = $_SESSION['url'];
        $result = $_SESSION['result'];
        unset($_SESSION['url']);
        unset($_SESSION['result']);
        switch ($result){
            case -2: $answer = "خطا در تکمیل خرید: برنامه خرید درخواستی وچود ندارد"; break;
            case -1: $answer = "خطا در تکمیل خرید: امکان ثبت وجود ندارد"; break;
            case 1: $answer = "خرید با موفقیت انجام شد"; break;
        }
    } else {
        header("location: user_panel.php"); // or better to a error page.
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <style>
        .row{
            display: flex;
            justify-content: center;
            align-items: center;
            border: 1px solid;
            border-radius: 10px;
            margin: 20px 50px;
        }
        .res{
            text-align: center;
        }
        .res p {
            font-size: 16px;
            font-weight: bold;
            color: red;
        }
        .res button{
            font-size: 12px;
            font-weight: bold;
            padding: 8px 16px;
            margin-bottom: 10px;
        }
    </style>
</head>
<body>
    <div class="row">
        <div class="res">
            <p><?php echo $answer ?></p>
            <button onclick="window.location.href='<?php echo $url ?>'">بازگشت به سایت پذیرنده</button>
            <p id="p_counter"></p>
        </div>
    </div>
    <script>
        p_counter.innerText = 5;
        var go = setInterval(fCounter,1000);
        function fCounter() {
            p_counter.innerText--;
            if(p_counter.innerText == 0){
                clearInterval(go);
                window.location.href="<?php echo $url ?>";
            }
        }
    </script>
</body>
</html>
