function ff(father){
    let a = father.querySelector(".kia_op_list");
    let op_lists = document.querySelectorAll('.kia_op_list');
    for(i = 0; i < op_lists.length; i++){
        if(op_lists[i] != a) {
            op_lists[i].style.display = "none";
            op_lists[i].parentElement.classList.remove('kia_op_01_active');
        }
    }
    if((a.style.display == 'none' || a.style.display == '') && a.innerText.trim() != ''){
        a.style.display = 'block';
        father.classList.add('kia_op_01_active')
    } else {
        a.style.display = 'none';
        father.classList.remove('kia_op_01_active')
    }
}
function f_select(father){
    father.parentElement.previousElementSibling.value = father.innerText;
}

function filter_op(father,ar_source, action = true){
    function f1(ele) {
        if(ele.indexOf(father.value) != -1) {
            return ele;
        }
    }
    function f2(ele) {
        return ele;
    }
    if(father.value !="") {
        var ar_return = ar_source.filter(f1);
    } else {
        var ar_return = ar_source.filter(f2);
    }
    var result = "";
    if(ar_return.length > 0) {
        for (i = 0; i < ar_return.length; i++) {
            result += "<div onclick='f_select(this)'>" + ar_return[i] + "</div>";
            if(action == true) {
                father.nextElementSibling.style.display = "block";
                father.parentElement.classList.add('kia_op_01_active');
            }

        }
    } else {
        father.nextElementSibling.style.display = "none";
        father.parentElement.classList.remove('kia_op_01_active');
    }
    father.nextElementSibling.innerHTML = result;
}