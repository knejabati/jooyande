<?php
    session_start();
    if(!isset($_SESSION['username'])){
        header("location: dex.php");
    }
    include_once "functions.php";
    include_once "../function/p_date.php";
    $add_result = $filter_province = $provinces = "";
    $ar_province = '[';
    $conn = jooyande();
    $q = "SELECT DISTINCT `province` FROM `city`";
    $r = $conn->query($q);
    if($r->num_rows > 0){
        while($data = $r->fetch_assoc()){
            $filter_province .= "<div onclick='f_select(this), get_city(this)'>" . $data['province'] . "</div>";
            $ar_province .= '\'' . $data['province'] . '\',';
        }
        $ar_province .= '];';
    }
    if($_SERVER['REQUEST_METHOD'] == "POST"){
        $city = $_POST['city'];
        $description = $_POST['description'];
        $note = $_POST['note'];
        $price = $_POST['price'];
        $status = $_POST['status'];
        $phone = $_POST['phone'];
        $call_time = $_POST['time'];
        //TODO write a function to change number to iranian number
        //TODO do something to upload pictures. (check if jpeg has been sent)
        if (empty($city)){
            $add_result = 0;
        }
        if (empty($description)){
            $add_result = 1;
        }
        if (empty($phone)){
            $add_result = 2;
        }
        if(!is_numeric($price) || $price <= 0){
            $add_result = 3;
        }
        if(empty($add_result)){ // no error has occurred.
            if(!isset($conn)) {
                $conn = jooyande();
            }
            $q = "select id from city where name = '$city'";
            $r = $conn->query($q);
            if($r->num_rows != 1) {
                $add_result = 4;
            }
            $data = $r->fetch_assoc();
            $city_id = $data['id'];

            $username = $_SESSION['username'];
            $q = "SELECT `id` FROM `user` WHERE `email` = '$username'";
            $r = $conn->query($q);
            if ($r->num_rows != 1){
                $add_result = 5;
            }
            $data = $r->fetch_assoc();
            $user_id = $data['id'];

            $q = "INSERT INTO `ad` (`user_id`,`date`,`city_id`,`desc`,`note`,`price`,`status`,`phone`,`call_time`) values ('$user_id',NOW(),'$city_id','$description','$note','$price','$status','$phone','$call_time')";
            if ($conn->query($q) === true){
                $ad_id = $conn->insert_id;
                if(!isset($_FILES['picture']) || $_FILES['picture']['error'][0] == UPLOAD_ERR_NO_FILE ) { // or 4
                    $files_count = 0;
                } else {
                    $files_count = count($_FILES['picture']['name']);
                }
                $file_error = 0;
                for($i=0; $i < min($files_count,4);$i++){
                    $tmp_name = $_FILES['picture']['tmp_name'][$i];
                    $name = $_FILES['picture']['name'][$i];
                    $type = $_FILES['picture']['type'][$i];
                    $size = $_FILES['picture']['size'][$i];
                    if(substr($type,0,5) == "image"){
                        if($size <= 3150000){
                            $ext = pathinfo($name,PATHINFO_EXTENSION);
                            $fileName = "p_" . $ad_id . "_$i." . $ext;
                            move_uploaded_file($tmp_name,"uploads/" . $fileName);
//                            $q = "INSERT INTO `photo` (`ad_id`,`URL`) VALUES ('$ad_id','$fileName')"
//                            $conn->query($q); NO NEED TO SAVE file name in seperate tables you can find them with their file names p_id_counter.*;
                        } else {
                            $file_error = 1;
                        }
                    } else {
                        $file_error = 1;
                    }
                }
                $add_result = 6;
                if($file_error === 1){
                    $add_result = 7;
                }
                unset($_POST['city']);
            } else {
                $add_result = 8;
            }
        }
        header("location: add_ad.php?ans=$add_result");
    } else {
         if(isset($_GET['ans'])) {
             switch ($_GET['ans']) {
                 case 0:
                     $add_result = "لطفا نام شهر را انتخاب نمایید";
                     break;
                 case 1:
                     $add_result = "لطفا عنوان آگهی را وارد نمایید";
                     break;
                 case 2:
                     $add_result = "لطفا شماره تلفن تماس را نمایید";
                     break;
                 case 3:
                     $add_result = "لطفا مقداری عددی برای قیمت وارد نمایید";
                     break;
                 case 4:
                     $add_result = "نام شهر معتبر نیست";
                     break;
                 case 5:
                     $add_result = "در ثبت اطلاعات خطایی رخ داد، لطفا از کاربری خود خارج شوید";
                     break;
                 case 6:
                     $add_result = "اطلاعات با موفقیت ثبت شد. جهت مدیریت آگهی به پنل کاربری خود بروید";
                     break;
                 case 7:
                     $add_result = "اطلاعات با موفقیت ثبت شد. جهت مدیریت آگهی به پنل کاربری خود بروید" . "<br/>" . "برخی از عکس ها به دلیل صحیح نبودن فرمت یا زیاد بودن سایز ذخیره نشدند";
                     break;
                 case 8:
                     $add_result = "خطا در ثبت اطلاعات.";
                     break;
                 default: $add_result = "";
             }
         }
    }
?>
<!DOCTYPE html>
<html lang="fa">
    <?php include "head.php" ?>
<body>
    <?php include "header.php" ?>
    <div class="div_save_ad cont01">
        <form method="post" enctype="multipart/form-data" onsubmit="return add_ad_check()">
            <label for="province" class="label_style">استان</label>
            <div class="kia_op_01" onclick="ff(this)">
                <input type="text" name="select_provice" id="select_province" class="Input_style" oninput="filter_op(this,ar_province)" placeholder="نام استان را انتخاب نمایید" autocomplete="off"/>
                <div class="kia_op_list">
                    <?php echo $filter_province; ?>
                </div>
            </div><br/>
            <label for="city" class="label_style">شهر</label>
            <div class="kia_op_01" onclick="ff(this)">
                <input type="text" name="city" id="select_city" class="Input_style" oninput="filter_op(this,ar_city)" placeholder="نام شهر را انتخاب نمایید" autocomplete="off"/>
                <div class="kia_op_list" id="div_get_city">
                </div>
            </div><br/>
            <label for="description" class="label_style">عنوان</label>
            <input type="text" name="description" id="description" class="Input_style" required><br/>
            <dl style="margin:0">
                <dt><label for="note" class="label_style">توضیحات</label></dt>
                <dt><textarea name="note" id="note" rows="5" class="Input_style" style="height: initial"></textarea></dt>
            </dl><br/>
            <label for="price" class="label_style">قیمت (تومان)</label>
            <input type="number" name="price" id="price" class="Input_style" oninput="write_p(this.value)" required><br/>
            <span id="lblPersian"></span><br/>
            <div class="div_select">
                <label class="label_style">وضعیت</label>
                <input type="radio" name="status" value="1" id="rdo_new" checked />
                <label for="rdo_new" class="label_style">نو</label>
                <input type="radio" name="status" value="0" id="rdo_used"/>
                <label for="rdo_used" class="label_style">کارکرده</label>
            </div><br/>
            <label for="phone" class="label_style">تلفن</label>
            <input type="text" name="phone" id="phone" class="Input_style" required value='<?php echo $_SESSION['phone'];?>'><br/>
            <label for="time" class="label_style">ساعت تماس</label>
            <input type="text" name="time" id="time" class="Input_style"><br/>
            <label for="picture" class="label_style">انتخاب عکس</label>
            <input type="file" id="picture" name="picture[]" class="Input_style" multiple accept="image/*"/><br/>
            <div class="pictures">
                <div class="picture"><img class="pic" src=""></div>
                <div class="picture"><img class="pic" src=""></div>
                <div class="picture"><img class="pic" src=""></div>
                <div class="picture"><img class="pic" src=""></div>
            </div><br/>
            <button type="submit" id="btn_save" class="btn">ذخیره</button>
            <button type="reset" id="btn_cancel" class="btn">لغو</button>
            <div>
                <p id="p_result"><?php echo $add_result; ?></p>
            </div>
        </form>
    </div>
    <script>
        var ar_province = <?php echo $ar_province; ?>
    </script>
    <script src="app.js"></script>
    <script src="p_number.js"></script>
    <script src="kia_option.js"></script>
    <script>
        // document.getElementById('picture').onclick = function(){console.log("now clicked")};
        document.getElementById('picture').onchange = function(){
            let fileCount = this.files.length;
            if(fileCount > 4){
                this.value=this.defaultValue;
                window.alert("امکان انتخاب بیشتر از 4 عکس ممکن نیست")
                return false;
            }

            //empty all the divs assocciated to pics
            let pics = document.getElementsByClassName('pic');
            let i = 0;
            for(i=0; i <= 3; i++){
                pics[i].src = "";
            }

            for(i = 0; i < Math.min(fileCount , 4); i++){
                if (!this.files[i].type.startsWith('image/')){ continue }
                pics[i].src = window.URL.createObjectURL(this.files[i]);
                pics[i].onload = function() {
                    window.URL.revokeObjectURL(this.src); // i don't know why this is required
                }
            }
        }
        function write_p(v) {
            lblPersian.innerText = p_number(v) + " " + "تومان";
        }
    </script>
</body>
</html>