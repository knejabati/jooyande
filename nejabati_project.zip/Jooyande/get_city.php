<?php
/**
 * Created by PhpStorm.
 * User: kiavash
 * Date: 4/30/2019
 * Time: 12:17 AM
 */
include_once "functions.php";
$province = trim(file_get_contents('php://input'));
$conn = jooyande();
if (stripos($_SERVER['HTTP_REFERER'],'add_ad.php')) {
    $q = "SELECT distinct `name` FROM `city` WHERE `province` = '$province'"; //request is sent from ad_add.php
} elseif(stripos($_SERVER['HTTP_REFERER'],'dex.php')) {
    $q = "SELECT DISTINCT `name` FROM `city` WHERE `province` = '$province' AND `id` IN (SELECT DISTINCT `city_id` FROM `ad` WHERE NOT ISNULL(`approved`) AND ISNULL(`finished`))";//request is sent from index.php
}
$r = $conn->query($q);
$result = "";
$ar_city = array();
$i= 0;
while ($data = $r->fetch_assoc()){
    $result .= "<div onclick='f_select(this)'>" . $data['name'] . "</div>";
    $ar_city[$i] = $data['name'];
    $i++;
}
//echo $result;
echo json_encode($ar_city);
