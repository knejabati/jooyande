<?php
/**
 * Created by PhpStorm.
 * User: kiavash
 * Date: 4/27/2019
 * Time: 12:19 AM
 */
session_start();
include_once "functions.php";
include_once "../function/p_date.php";
if (!isset($_SESSION['username'])){
    header("location: dex.php");
} else {
    $user = $_SESSION['username'];
    $user_id = $_SESSION['user_id'];
    $answer = '';
}
$conn = jooyande();
if($_SERVER['REQUEST_METHOD'] == "POST"){
    $e = 0;
    isset($_POST['gender']) ? $gender = $_POST['gender'] : $e = 1;
    isset($_POST['fname']) ? $fname = $_POST['fname'] : $e = 1;
    isset($_POST['lname']) ? $lname = $_POST['lname'] : $e = 1;
    isset($_POST['phone']) ? $phone = $_POST['phone'] : $e = 1;
    if($e == 0){
        $q = "UPDATE `user` SET `gender` = '$gender', `fname` = '$fname', `lname` = '$lname', `phone` = '$phone' WHERE `email` = '$user' ";
        if ($r = $conn->query($q)){
            $user_ar = array('id'=>$user_id, 'email'=>$user, 'gender'=>$gender, 'fname'=>$fname, 'lname'=>$lname, 'phone'=>$phone);
            set_user_session($user_ar);
            $answer = 'اطلاعات با موفقیت به روز شدند';
        } else{
            $answer = 'خطا در ویرایش اطلاعات';
        }
    } else {
        $answer = 'اطلاعات وارد شده معتبر نیستند';
    }
}

$q = "SELECT * FROM `user` WHERE `email` = '$user'";
$r = $conn->query($q);

if($data = $r->fetch_assoc()){
    extract($data);
    $q = "SELECT `ad`.*, (SELECT `city`.`name` FROM `city` WHERE `city`.`id` = `ad`.`city_id`) AS `city` FROM `ad` WHERE `user_id` = '$user_id'";
    $ads_dataset = $conn->query($q);
    $table = ads_table($ads_dataset);
} else {
    header("location: dex.php");
}
$conn->close();
?>

<!DOCTYPE html>
<html lang="fa">
    <?php include "head.php"; ?>
<body>
    <?php include "header.php"; ?>
    <div class="cont01">
        <div class="div_answer">
            <h4 id="h4_answer"><?php echo $answer ?></h4>
        </div>
        <label class="label_style username"><?php echo $email ?></label>
        <form method="post">
            <label for="gender" class="label_style">جنسیت</label>
            <select id="gender" name="gender" class="Input_style select_style" disabled value="<?php echo $gender ?>">
                <option <?php echo ($gender == 'آقای') ? "selected='selected'" : '' ?> value="آقای">آقای</option>
                <option <?php echo ($gender == 'خانم') ? "selected='selected'" : '' ?> value="خانم">خانم</option>
<!--                <option value="آقای">آقای</option>-->
<!--                <option value="خانم">خانم</option>-->
            </select><br/>
            <label for="fname" class="label_style">نام:</label>
            <input type="text" name="fname" id="fname" class="Input_style" disabled value="<?php echo $fname ?>"/><br/>
            <label for="lname" class="label_style">نام خانوادگی:</label>
            <input type="text" name="lname" id="lname" class="Input_style" disabled value="<?php echo $lname ?>"/><br/>
            <label for="phone" class="label_style">شماره تلفن</label>
            <input type="text" name="phone" id="phone" class="Input_style" disabled value="<?php echo $phone ?>"/><br/>
            <button type="button" id="btn_edit" onclick="edit_mode()" class="btn">ویرایش</button>
            <button type="button" id="btn_change_psw" onclick="window.location.href = 'change_psw.php?user_id=<?php echo $user_id ?>'" class="btn">تغییر رمز</button>
            <button type="submit" id="btn_save" class="btn" hidden>ذخیره</button>
            <button type="button" id="btn_cancel" onclick="edit_cancel()" class="btn" hidden>کنسل</button>
        </form>
    </div>
    <div class="cont01">
        <h3>اطلاعات آگهی های ثبت شده</h3>
        <div class="div_table">
            <?php echo $table ?>
        </div>
    </div>
    <script>
        function edit_mode() {
            btn_edit.hidden = true;
            btn_save.hidden = false;
            btn_cancel.hidden = false;
            btn_change_psw.hidden = true;
            gender.disabled = false;
            fname.disabled = false;
            lname.disabled = false;
            phone.disabled = false;
        }
        function edit_cancel() {
            btn_edit.hidden = false;
            btn_save.hidden = true;
            btn_cancel.hidden = true;
            btn_change_psw.hidden = false;
            gender.disabled = true;
            fname.disabled = true;
            lname.disabled = true;
            phone.disabled = true;
            gender.selectedIndex = gender.defaultSelected;
            fname.value = fname.defaultValue;
            lname.value = lname.defaultValue;
            phone.value = phone.defaultValue;
        }
    </script>
</body>
</html>
