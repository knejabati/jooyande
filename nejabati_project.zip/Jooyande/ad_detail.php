<?php
session_start();
if(!isset($_SESSION['click'])){
    $_SESSION['click'] = array();
}
include_once "functions.php";
include_once "../function/p_date.php";

if(isset($_SESSION['ids'])){
    $ids = $_SESSION['ids'];
} else {
    header("location: dex.php");
}
if($_SERVER['REQUEST_METHOD'] == "GET"){
    $id = $_GET['q'];
    $current_ad = array_search($id,$ids);
    $next_id = (isset($ids[$current_ad + 1])) ? $ids[$current_ad + 1] : false;
    $prev_id = (isset($ids[$current_ad - 1])) ? $ids[$current_ad - 1] : false;
    $conn = jooyande();
    $q = "SELECT    `ad`.`id`,
                    `ad`.`date`,
                    (SELECT `name` FROM `city` WHERE `id` = `ad`.`city_id`) as `city`,
                    `ad`.`desc`,
                    `ad`.`note`,
                    `ad`.`price`,
                    `ad`.`status`,
                    `ad`.`phone`,
                    `ad`.`call_time`,
                    (SELECT COUNT(`sales`.`id`) FROM `sales` LEFT JOIN `salesplan` ON `sales`.`salesplan_id`=`salesplan`.`id` 
                              WHERE DATE_ADD(`sales`.`date`,INTERVAL `salesplan`.`duration` DAY) >= NOW() AND `sales`.`ad_id`=`ad`.`id`) as `rank`
                FROM `ad`
                WHERE `ad`.`id` = '$id'";
    $r = $conn->query($q);
    $data = $r->fetch_assoc();
    $date = p_date_mysql($data['date']);
    $city = $data['city'];
    $desc = $data['desc'];
    $note = $data['note'];
    $phone = $data['phone'];
    $price = $data['price'];
    $status = ($data['status'] == 1) ? 'نو' : 'کار کرده';
    $call_time = $data['call_time'];
    $img = get_ad_photos($id,$desc);
    //ad clicked field by on
    if(!in_array($id,$_SESSION['click'])) {
        $q1 = "UPDATE `ad` SET `clicked`=`clicked`+1 WHERE `id`= '$id'";
        $conn->query($q1);
        array_push($_SESSION['click'], $id);
    }
    $conn->close();

}

?>

<!DOCTYPE html>
<html lang="fa">
    <?php include "head.php" ?>
<body>
    <?php include "header.php" ?>
    <div class="cont01">
        <div class="div_detail">
            <div class="div_ad_detail">
                <div class="div_field">
                    <label class="caption">عنوان:</label>
                    <label id="lbl_desc"><?php echo $desc . "</label>" . '  ' . (($data['rank'] >= 1) ? '<span>ویژه</span>' : '')?>
                </div>
                <div class="div_field">
                    <label class="caption">تاریخ:</label>
                    <label id="lbl_date"><?php echo $date; ?></label>
                </div>
                <div class="div_field">
                    <label class="caption">شهر:</label>
                    <label id="lbl_city"><?php echo $city; ?></label>
                </div>
                <div class="div_field">
                    <label class="caption">قیمت(تومان):</label>
                    <label id="lbl_price"><?php echo number_format($price,0); ?></label>
                </div>
                <div class="div_field">
                    <label class="caption">تلفن:</label>
                    <label id="lbl_phone"><?php echo $phone; ?></label>
                </div>
                <div class="div_field">
                    <label class="caption">زمان تماس:</label>
                    <label id="lbl_time"><?php echo $call_time; ?></label>
                </div>
                <div class="div_field">
                    <label class="caption">وضعیت:</label>
                    <label id="lbl_status"><?php echo $status; ?></label>
                </div>
            </div>
            <br/>
            <div class="div_ad_detail2">
                <label class="caption">توضیحات:</label>
                <label id="lbl_note"><?php echo $note; ?></label>
            </div>
            <div class="div_picture">
                <?php echo $img; ?>
            </div>
            <div class="div_nav">
                <button id="btn_next" class="btn" onclick="navigate(this)" <?php echo (!$next_id) ? "disabled" : "data-id='$next_id'" ?>>بعدی</button>
                <button id="btn_prev" class="btn" onclick="navigate(this)" <?php echo (!$prev_id) ? "disabled" : "data-id='$prev_id'" ?>>قبلی</button>
            </div>
        </div>
    </div>
    <script src="app.js"></script>
</body>
</html>