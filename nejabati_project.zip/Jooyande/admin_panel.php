<?php
/**
 * Created by PhpStorm.
 * User: kiavash
 * Date: 5/3/2019
 * Time: 5:03 PM
 */
session_start();
include_once "functions.php";
if(!isset($_SESSION['admin'])){
    header("location: admin_signin.php");
} else {
    $admin = $_SESSION['admin']['fname'] . " " . $_SESSION['admin']['lname'];
}

$sales_plans = get_sales_plans(false);

?>

<!DOCTYPE html>
<html lang="fa">
    <head>
        <meta charset="UTF-8"/>
        <title>پنل مدیریت سایت جوینده</title>
        <link rel="stylesheet" href="style.css"/>
        <link rel="stylesheet" media="screen and (min-width:812px)" href="style_pc.css"/>
    </head>
    <body>
        <div class="cont01">
            <p id="result"><?php echo $admin; ?></p>
        </div>
        <div class="cont01">
            <div class="d_checkbox">
                <input type="radio" id="all_ads" name="ads" value="1" onclick="filter_ad(this)" checked/>
                <label class="label_style" id="all_ads" for="all_ads">کل آگهی های ثبت شده</label>
            </div>
            <div class="d_checkbox">
                <input type="radio" id="active_ads" name="ads" value="2" onclick="filter_ad(this)"/>
                <label class="label_style" for="active_ads">آگهی های فعال</label>
            </div>
            <div class="d_checkbox">
                <input type="radio" id="finished_ads" name="ads" value="3" onclick="filter_ad(this)"/>
                <label class="label_style" for="finished_ads">آگهی های منقضی شده</label>
            </div>
            <div class="d_checkbox">
                <input type="radio" id="rejected_ads" name="ads" value="4" onclick="filter_ad(this)"/>
                <label class="label_style" for="rejected_ads">آگهی های مردود</label>
            </div>
            <div class="d_checkbox">
                <input type="radio" id="special_ads" name="ads" value="5" onclick="filter_ad(this)"/>
                <label class="label_style" for="special_ads">آگهی های ویژه</label>
            </div>
            <div class="d_checkbox">
                <input type="radio" id="new_ads" name="ads" value="6" onclick="filter_ad(this)"/>
                <label class="label_style" for="new_ads">آگهی های جدید بررسی نشده</label>
            </div>
        </div>
        <div class="cont01">
            <div class="div_table">
                <label class="caption">تعداد کل: </label>
                <label id="total">36 مورد</label>
                <table id="ad_table" cellspacing="0">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>شرح</th>
                            <th>کاربر</th>
                            <th>شهر</th>
                            <th>وضعیت</th>
                            <th>تاریخ</th>
                        </tr>
                    </thead>
                    <tbody id="my_tbody">
                        <tr>
                            <td>1</td>
                            <td>تلوزیون</td>
                            <td>کیانوش نجابتی</td>
                            <td>شهر جدید هشتگرد</td>
                            <td>منتظر بررسی</td>
                            <td>98/02/12</td>
                        </tr>
                    </tbody>
                </table>
                <div id="links">
                    <a href="#">1</a>
                </div>
            </div>
        </div>
        <div class="cont01">
            <strong>مدیریت برنامه های فروش</strong>
            <div class="div_table2">
                <?PHP echo $sales_plans ?>
            </div>
            <a href="salesplans.php" style="font-size: 12px; text-decoration: unset">ایجاد برنامه فروش جدید</a>
        </div>
    <script src="app.js"></script>
    <script>
        let ele = document.getElementById('all_ads');
        filter_ad(ele);
    </script>
    </body>
</html>
