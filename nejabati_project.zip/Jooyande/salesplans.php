<?php
/**
 * Created by PhpStorm.
 * User: kiavash
 * Date: 6/5/2019
 * Time: 9:44 PM
 */
session_start();
if(!isset($_SESSION['admin'])){
    header("location: admin_signin.php");
} else {
    $admin = $_SESSION['admin']['fname'] . " " . $_SESSION['admin']['lname'];
}
include_once "functions.php";
$description = $duration = $price = '';
$status = 0;
if(isset($_GET['plan'])){
    $plan_ar2 = get_plan_info($_GET['plan']);
    if($plan_ar2 != false) {
        extract($plan_ar2);
    } else {
        header("location: admin_panel.php");
    }
}
if($_SERVER['REQUEST_METHOD'] == "POST"){
    $description = isset($_POST['description']) ? $_POST['description'] : null;
    $duration = isset($_POST['duration']) ? $_POST['duration'] : null;
    $status = isset($_POST['status']) ? $_POST['status'] : null;
    $price = isset($_POST['price']) ? $_POST['price'] : null;
    $plan_ar = array($description, $duration, $status, $price);
    if(is_null($description) || is_null($duration) || is_null($status) || is_null($price)){
        $answer = "اطلاعات ارسال شده کامل نبودند، ثبت انجام نشد";
    } elseif (isset($_GET['plan'])) {
        $r = update_plan($_POST,$_GET['plan']);
        if($r){
            $answer = "برنامه فروش با موفقبت ویرایش شد";
        } else {
            $answer = "برنامه فروش ویرایش نشد، خطایی پیش آمد";
        }
    } else {
        $r = ad_plan($_POST);
        if($r){
            $answer = "برنامه فروش با موفقیت ثبت شد";
            header("location: admin_panel.php");
        } else {
            $answer = "برنامه فروش ثبت نشد، خطایی در ذخیره پیش آمد";
        }
    }
}
?>

<html lang="fa">
<head>
    <meta charset="UTF-8"/>
    <title>پنل مدیریت سایت جوینده</title>
    <link rel="stylesheet" href="style.css"/>
</head>
<body>
    <div class="cont01">
        <p id="result"><a href="admin_panel.php"><?php echo $admin; ?></a></p>
    </div>
    <div class="cont01">
        <div class="div_answer">
            <h4 id="h4_answer"><?php echo (isset($answer)) ? $answer : '' ?></h4>
        </div>
        <form method="post">
            <label for="description" class="label_style">شرح برنامه</label>
            <input type="text" name="description" value="<?php echo $description ?>" class="Input_style" required autocomplete="off" title=""/><br/>
            <label for="duration" class="label_style">مدت تاثیر (روز)</label>
            <input type="number" name="duration" value="<?php echo $duration ?>" class="Input_style" required autocomplete="off" title=""/><br/>
            <label for="price" class="label_style">قیمت(تومان)</label>
            <input type="number" name="price" value="<?php echo $price ?>" class="Input_style" required autocomplete="off" title=""/><br/>
            <label for="description" class="label_style">وضیت</label>
            <select id="status" name="status" class="Input_style select_style">
                <option value="1" <?php echo $status == 1 ? "selected" : "" ?>>فعال</option>
                <option value="0" <?php echo $status == 0 ? "selected" : "" ?>>غیرفعال</option>
            </select><br/>
            <button type="submit" class="btn"> ذخیره کن</button>
            <button type="reset" class="btn">پاک کن</button>
            <button type="button" onclick="window.location.href='admin_panel.php'" class="btn">بازگشت به پنل مدیریت</button>
        </form>
    </div>
</body>
</html>
