<?php
/**
 * Created by PhpStorm.
 * User: kiavash
 * Date: 6/4/2019
 * Time: 11:09 PM
 */

function jooyande(){
    $c = new mysqli('localhost', 'root', '', 'jooyande');
    if ($c->connect_error){
        die("Error on connecting to the database!" . '<br/>' . $c->connect_error);
    }
    $c->set_charset("UTF8");
    return $c;
}

function get_user($user){
    $conn = jooyande();
    $q = "select id,email,gender,fname,lname,phone from `user` where email = trim('$user') ";
    $r = $conn->query($q);
    if($re_user = $r->fetch_assoc()) {
        return $re_user;
    } else {
        return false;
    }
}

function set_user_session($username){
    if(!isset($username['id']) || !isset($username['email']) || !isset($username['fname']) || !isset($username['lname']) || !isset($username['gender']) || !isset($username['phone'])){
        return false;
    }
    $_SESSION['user_id'] = $username['id'];
    $_SESSION['username'] = $username['email'];
    $_SESSION['nickname'] = $username['gender'] . ' ' . $username['fname'] . ' ' . $username['lname'];
    $_SESSION['phone'] = $username['phone'];
    return true;
}

function ads_table($ad_row){
    $return = "<table id='ad_table'>
        <thead>
            <tr>
                <th>#</th>
                <th>تاریخ</th>
                <th>شهر</th>
                <th>عنوان</th>
                <th>قیمت</th>
                <th>وضیت آگهی</th>
                <th>impr</th>
                <th>click</th>
                <th>مدیریت آگهی</th>
            </tr>
        </thead>
        <tbody>";
    $i = 0;
    while ($ad = $ad_row->fetch_assoc()){
        $i++;
        extract($ad);
        $status = get_ad_status($ad);
        $return .= "<tr>
                <td>$i</td>
                <td style='font-size:8px'>" . p_date_mysql($date) . "</td>
                <td>$city</td>
                <td>$desc</td>
                <td>$price</td>
                <td>$status</td>
                <td>$impression</td>
                <td>$clicked</td>
                <td><a href='ad_edit.php?ad_id=" . $id ."'>ویرایش</a></td>
          </tr>";
    }
    return $return;
}

function get_ad($ad_id, $user_id){
    $conn = jooyande();
    $q = "SELECT `ad`.*, (SELECT `city`.`name` FROM `city` WHERE `city`.`id` = `ad`.`city_id`) AS `city` FROM `ad` WHERE `id` = '$ad_id' AND `user_id`='$user_id'";
    $r = $conn->query($q);
    if($r->num_rows == 1){
        $r2 = $r->fetch_assoc();
        $conn->close();
        return  $r2;
    } else {
        $conn->close();
        return null;
    }

}

function get_ad_status($ad_ar){
    extract($ad_ar);
    if(is_null($rejected) && is_null($approved) && is_null($finished)){
        $status = 'منتظر تایید';
    } elseif (!is_null($finished)){
        $status = 'بسته شده';
    } elseif (!is_null($rejected)){
        $status = 'مردود/مدیر سایت';
    } elseif (!is_null($approved)){
        $status = 'فعال';
    } else {
        $status = 'نامشخص';
    }
    return $status;
}

function ad_cancel($ad_id,$user_id){
    $conn = jooyande();
    $q = "UPDATE `ad` SET `finished`=now() WHERE `id`='$ad_id' AND `user_id`='$user_id'";
    $r = $conn->query($q);
    if($conn->affected_rows == 1){
        $conn->close();
        return true;
    } else {
        $conn->close();
        return false;
    }
}

function ad_save($ad_id, $user_id, $new_values){
    $conn = jooyande();
    if(isset($new_values['desc'])){
        $desc = $new_values['desc'];
    } else {
        return false;
    }
    if(isset($new_values['note'])){
        $note = $new_values['note'];
    } else {
        return false;
    }
    if(isset($new_values['price'])){
        $price = $new_values['price'];
    } else {
        return false;
    }

    if(isset($new_values['status'])){
        $status = $new_values['status'];
    } else {
        return false;
    }

    if(isset($new_values['phone'])){
        $phone = $new_values['phone'];
    } else {
        return false;
    }
    if(isset($new_values['call_time'])){
        $call_time = $new_values['call_time'];
    } else {
        return false;
    }
    $q = "UPDATE `ad` SET `desc`='$desc',`note`='$note',`price`='$price', `status`='$status', `phone`='$phone', `call_time`='$call_time' WHERE `id`='$ad_id' AND `user_id`='$user_id'";
    $r = $conn->query($q);
    if($conn->affected_rows == 1){
        $conn->close();
        return true;
    } else {
        $conn->close();
        return false;
    }
}

function get_ad_photos($ad_id, $desc){
    $pics = glob("uploads/p_" . $ad_id . "_*.*");
    $pics1 = (isset($pics[0])) ? $pics[0] . " alt='" . $desc . "'" : "''";
    $pics2 = (isset($pics[1])) ? $pics[1] . " alt='" . $desc . "'" : "''";
    $pics3 = (isset($pics[2])) ? $pics[2] . " alt='" . $desc . "'" : "''";
    $pics4 = (isset($pics[3])) ? $pics[3] . " alt='" . $desc . "'" : "''";
    $r =   "<img src=$pics1/>
            <img src=$pics2/>
            <img src=$pics3/>
            <img src=$pics4/>";
    return $r;
}

function check_active_user(){
    if(isset($_SESSION['username'])){
        $result = "<a href='user_panel.php'>" . $_SESSION['nickname'] . "</a><a href='dex.php?exit=true'>خروج از سیستم</a>";
    } else {
        $result = "<a href='signin.php'>ورود/ثبت نام</a>";
    }
        return $result;
}

function check_psw($user_id,$old_psw){
    if(!isset($conn)){
        $conn = jooyande();
        $q = "SELECT `psw` FROM `user` WHERE `id` = '$user_id'";
        $r = $conn->query($q);
        if($data = $r->fetch_assoc()){
            if(password_verify($old_psw, $data['psw'])){
                return true;
            }
        }
        return false;
    }
}

function change_psw($user_id,$new_psw){
    if(!isset($conn)){
        $conn = jooyande();
        $new_psw_h = password_hash($new_psw,1);
        $q = "UPDATE `user` SET `psw`='$new_psw_h' WHERE `id`='$user_id'";
        $r = $conn->query($q);
        if($conn->affected_rows == 1){
            return true;
        } else {
            return flase;
        }
    }
}

function get_sales_plans($for_purchase){
    $close = false;
    if(!isset($conn)){
        $conn = jooyande();
        $close = true;
    }
    if(!$for_purchase) {
        $q = "SELECT `salesplan`.*,
                (SELECT `price` FROM `salesprice` WHERE `salesplan_id` = `salesplan`.`id` ORDER BY `date` DESC LIMIT 1) as `price`,
                (SELECT count(`id`) FROM `sales` WHERE `salesplan_id` = `salesplan`.`id` ) as statistics 
            FROM `salesplan`";
    } else {
        $q = "SELECT `salesplan`.*,
                (SELECT `price` FROM `salesprice` WHERE `salesplan_id` = `salesplan`.`id` ORDER BY `date` DESC LIMIT 1) as `price` 
            FROM `salesplan`  WHERE `status`=1";
    }
    $r = $conn->query($q);
    if($for_purchase){
        $result = "<select name='salesplan_id' id='salesplan' class='Input_style select_style' value=''>";
        while ($plan = $r->fetch_assoc()) {
            extract($plan);
            $result .= "<option value=$id>$description , $duration روز, $price تومان</option>";
        }
        $result .= "</select>";
        return $result;
    }
    if(!$for_purchase) {
        $i = 1;
        $body = "";
        while ($plan = $r->fetch_assoc()) {
            extract($plan);
            $status1 = $status == true ? "فعال" : "غیرفعال";
            $body .= "<tr>
                    <td>$i</td>
                    <td>$description</td>
                    <td>$duration</td>
                    <td>$price</td>
                    <td>$status1</td>
                    <td>$statistics</td>
                    <td><a href='salesplans.php?plan=$id' >ویرایش</a></td>
                </tr>";
            $i++;
        }
        $result = "<table id='ad_table'>
            <thead>
                <tr>
                    <th>#</th>
                    <th>شرح برنامه</th>
                    <th>مدت تاثیر(روز)</th>
                    <th>قیمت</th>
                    <th>وضیت</th>
                    <th>آمار فروش</th>
                    <th>مدیریت</th>
                </tr>
            </thead>
            <tbody>
                $body
            </tbody>
        </table>";
        if ($close == true) {
            $conn->close();
        }
        return $result;
    }
}

function ad_plan($plan_ar){
    $close = false;
    if(!isset($conn)){
        $conn = jooyande();
    }
    extract($plan_ar);
    $q1 = "INSERT INTO `salesplan` (`description`,`duration`,`status`) VALUES ('$description','$duration','$status')";
    $conn->begin_transaction();
    $r1 = $conn->query($q1);
    if($r1){
        $salesplan_id = $conn->insert_id;
        $q2 = "INSERT INTO `salesprice` (`salesplan_id`,`date`,`price`) VALUES ('$salesplan_id',now(),'$price')";
    } else {
        $conn->close();
        return false;
    }
    $r2 = $conn->query($q2);
    if($r2){
        $conn->commit();
        $conn->close();
        return true;
    } else {
        $conn->rollback();
        $conn->close();
        return false;
    }
}

function get_plan_info($plan){
    $close = false;
    if(!isset($conn)){
       $conn = jooyande();
        $close = true;
    }
    $q = "SELECT `salesplan`.*, 
                (SELECT `price` FROM `salesprice` WHERE `salesplan_id` = `salesplan`.`id` ORDER BY `date` DESC LIMIT 1) as `price` 
            FROM `salesplan` WHERE `id`='$plan'";
    $r = $conn->query($q);
    if($r->num_rows == 1){
        if($close == true) {
            $conn->close();
        }
        return $r->fetch_assoc();
    }
    if($close == true) {
        $conn->close();
    }
    return false;
}

function update_plan ($plan_ar,$plan){
    $conn = jooyande();
    extract($plan_ar);
    $q1 = "UPDATE `salesplan` SET `description`='$description',`duration`='$duration',`status`='$status' WHERE `id`='$plan'";
    $conn->begin_transaction();
    $conn->query($q1);
    if(empty($conn->error)){ // or $conn->errno == 0;
        //check if this price is alreay salved for this plan
        $q3 = "SELECT `id` FROM `salesprice` WHERE date(`date`) = date(now()) AND `price`='$price' AND `salesplan_id`='$plan'";
        $r3 = $conn->query($q3);
        if($r3->num_rows >= 1) {
            $conn->commit();
            $conn->close();
            return true;
        } else {
            $q2 = "INSERT INTO `salesprice` (`salesplan_id`,`date`,`price`) VALUES ('$plan',now(),'$price')";
            $r2 = $conn->query($q2);
            if($conn->affected_rows == 1){
                $conn->commit();
                $conn->close();
                return true;
            } else {
                $conn->rollback();
                $conn->close();
                return false;
            }
        }
    } else {
        $conn->rollback();
        $conn->close();
        return false;
    }
}

function get_ad_plan($ad_id){
    if(!isset($conn)){
        $conn = jooyande();
    }
    $ans = "";
    $q = "SELECT  `sales`.`id`,
                  `sales`.`date`,
                  `salesplan`.`description`,
                  `salesplan`.`duration`
              FROM `sales` LEFT JOIN `salesplan` ON `sales`.`salesplan_id`=`salesplan`.`id` WHERE `sales`.`ad_id` = '$ad_id' ORDER BY `sales`.`date` DESC";
    $r = $conn->query($q);
    $i = 0;
    while ($data = $r->fetch_assoc()){
        $i++;
        extract($data);
        if(strtotime($date . $duration . 'days') >= time()) {
            $status = "فعال";
        } else {
            $status = "منقضی";
        }
        $ans .= "<tr>
                    <td>$i</td>
                    <td>$description</td>
                    <td>$duration</td>
                    <td>" . p_date_mysql($date) . "</td>
                    <td>$status</td>
                </tr>";
    }
    return $ans;
}