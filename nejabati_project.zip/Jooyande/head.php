<head>
    <meta charset="UTF-8">
    <title>جوینده - سرویس آنلاین ثبت آگهی</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <meta name="author" content="Kianoosh Nejabati Zenooz"/>
    <meta name="description" content="سایت رایگان و آنلاین ثبت و جستجوی آگهی"/>
    <meta name="keywords" content="آگهی، ثبت آگهی، خرید، فروش، دست دوم، کارکرده"/>
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <!--TODO how they arrange different pages to show in search engines, should we create different pages for different categories?-->
    <link rel="stylesheet" href="style.css"/>
    <link rel="stylesheet" media="screen and (min-width:768px)" href="style_pc.css"/>
    <link rel="stylesheet" href="kia_option.css"/>
</head>
