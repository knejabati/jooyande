<?php
include_once "functions.php";
if (isset($_COOKIE['username'])) {
    $username = get_user($_COOKIE['username']);
    if ($username) {
        set_user_session($username);
    }
}
?>
<header>
    <div class="div_title">
        <h1>جوینده</h1>
        <h4>سرویس آنلاین آگهی</h4>
    </div>
    <div class="div_icon" onclick="window.location.href='dex.php'">
        <!--this div is only for logo (its background-image)-->
    </div>
    <div class="div_login">
        <?php echo check_active_user() ?>
    </div>
</header>