<?php
/**
 * Created by PhpStorm.
 * User: kiavash
 * Date: 6/5/2019
 * Time: 12:52 AM
 */
session_start();
if (!isset($_SESSION['username'])){
    header("location: dex.php");
} else {
    $user = $_SESSION['username'];
    $user_id = $_SESSION['user_id'];
    $url = $_SERVER['REQUEST_URI']; //to be sent to payment page
}
include_once "functions.php";
include_once "../function/p_date.php";
?>

<!DOCTYPE html>
<html lang="fa">
<?php include "head.php"; ?>
<body>
<?php
include "header.php";
if(isset($_GET['ad_id'])){
    $my_ad = get_ad($_GET['ad_id'],$user_id);
    if(is_null($my_ad)){
        $answer = "آگهی مورد نظر یافت نشد";
        header("location: user_panel.php");
    } else {
        if($_SERVER['REQUEST_METHOD'] == "POST"){
            if(isset($_POST['ad_cancel'])){
                $c = ad_cancel($_GET['ad_id'],$user_id);
                if($c == true){
                    $answer = "سفارش با موفقیت کنسل شد";
                } else {
                    $answer = "خطا در کنسل کردن سفارش";
                }
            } elseif(isset($_POST['ad_save'])){
                $c = ad_save($_GET['ad_id'],$user_id,$_POST);
                if($c == true){
                    $answer = "اطلاعات سفارش با موفقیت ویرایش شد";
                } else {
                    $answer = "خطا در ویرایش اطلاات سفارش";
                }
            }
        }
        extract($my_ad);
        $ad_status = get_ad_status($my_ad);
        $img = get_ad_photos($id,$desc);
        $ad_plan = get_ad_plan($id);
        $sales_plans = get_sales_plans(true);
    }
} else {
    header("location: user_panel.php");
}
?>

<div class="cont01">
    <h3>مشخصات آگهی</h3>
    <div class="div_answer">
        <h4 id="h4_answer"><?php echo (isset($answer)) ? $answer : '' ?></h4>
    </div>
    <form method="post">
        <table id="ad_table">
            <tr>
                <td>تاریخ</td>
                <td><?php echo p_date_mysql($date); ?></td>
            </tr>
            <tr>
                <td>شهر</td>
                <td ><?php echo $city; ?></td>
            </tr>
            <tr>
                <td>وضعیت سفارش</td>
                <td><?php echo $ad_status ; ?></td>
            </tr>
            <tr>
                <td>نمایش در نتبجه جستجو</td>
                <td><?php echo $impression ; ?></td>
            </tr>
            <tr>
                <td>دفعات کلیک شدن</td>
                <td><?php echo $clicked ; ?></td>
            </tr>
        </table>
        <label for="desc" class="label_style">شرح:</label>
        <input type="text" class="Input_style" name="desc" disabled required autocomplete="off" title="" value="<?php echo $desc; ?>"><br/>
        <label for="note" class="label_style">توضیحات:</label>
        <input type="text" class="Input_style" name="note" disabled required autocomplete="off" title="" value="<?php echo $note; ?>"><br/>
        <label for="price" class="label_style">قیمت:</label>
        <input type="text" class="Input_style" name="price" disabled required autocomplete="off" title="" value="<?php echo $price; ?>"><br/>
        <label for="status" class="label_style">وضعیت کالا:</label>
        <select id="status" name="status" class="Input_style select_style" required disabled>
            <option value="1" <?php echo (isset($status) && $status == 1) ? "selected" : ""; ?>>نو</option>
            <option value="0" <?php echo (isset($status) && $status == 0) ? "selected" : ""; ?>>کارکرده</option>
        </select><br/>
        <label for="phone" class="label_style">شماره تماس:</label>
        <input type="text" class="Input_style" name="phone" disabled required autocomplete="off" title="" value="<?php echo $phone; ?>"><br/>
        <label for="call_time" class="label_style">زمان تماس:</label>
        <input type="text" class="Input_style" name="call_time" disabled autocomplete="off" title="" value="<?php echo $call_time; ?>"><br/>
        <div class="div_picture">
            <?php echo $img; ?>
        </div><br/>
        <button type="submit" id="btn_cancel" class="btn" name="ad_cancel">کنسل کردن سفارش</button>
        <button type="button" id="btn_edit" class="btn" onclick="edit_mode()">ویرایش سفارش</button>
        <button type="submit" id="btn_save" class="btn" hidden name="ad_save">ذخیره</button>
        <button type="button" id="btn_cancel_edit" class="btn" onclick="edit_cancel()" hidden>کنسل</button>
    </form>
</div>
<div class="cont01">
    <h3>ارتقای آگهی</h3>
    <strong>خرید های قبلی</strong><br/>
    <table id='ad_table'>
        <thead>
            <tr>
                <th>#</th>
                <th>شرح</th>
                <th>مدت</th>
                <th>تاریخ خرید</th>
                <th>وضعیت</th>
            </tr>
        </thead>
        <tbody>
            <?php echo $ad_plan?>
        </tbody>
    </table>
    <strong>خرید جدید</strong>
    <form method="post" action="commit_purchase.php">
        <?php echo $sales_plans; ?><br/>
        <input type="hidden" name="ad_id" value="<?php echo $id ?>"/>
        <input type="hidden" name="user_id" value="<?php echo $user_id ?>"/>
        <input type="hidden" name="url" value="<?php echo $url ?>"/>
        <button type="submit" class="btn">پرداخت</button>
    </form>
</div>
    <script>
        function edit_mode() {
            for(i=0; i < document.forms[0].elements.length; i++){
                var ele = document.forms[0].elements;
                if ((ele[i].tagName == "INPUT" && ele[i].getAttribute('type') == "text") || ele[i].tagName == "SELECT"){
                    ele[i].disabled = false;
                }
                btn_edit.hidden = true;
                btn_cancel.hidden = true;
                btn_save.hidden = false;
                btn_cancel_edit.hidden = false;
            }
        }
        function edit_cancel() {
            for(i=0; i < document.forms[0].elements.length; i++) {
                var ele = document.forms[0].elements;
                if ((ele[i].tagName == "INPUT" && ele[i].getAttribute('type') == "text")) {
                    ele[i].disabled = true;
                    ele[i].value = ele[i].defaultValue;
                }
                if (ele[i].tagName == "SELECT") {
                    ele[i].disabled = true;
                    ele[i].selectedIndex = ele[i].defaultIndex;
                }
                btn_edit.hidden = false;
                btn_cancel.hidden = false;
                btn_save.hidden = true;
                btn_cancel_edit.hidden = true;
            }
        }
    </script>
</body>
</html>
