<?php
session_start();
if (!isset($_SESSION['search'])) {
    $_SESSION['search'] = array();
}
include_once "functions.php";
include_once "../function/p_date.php";
$result_text = "kianoosh";
if($_SERVER['REQUEST_METHOD'] == 'GET') {
    $result_text = '';
    $city = $_GET['city'];
    $keyword = $_GET['keyword'];
    $conn = jooyande();
    $q = "SELECT `id` FROM `city` WHERE `name` = '$city'";
    $r = $conn->query($q);
    if ($r->num_rows == 0) {
        $result_text = "با توجه به اطلاعات وارد شده هیچ آگهی یافت نشد";
    } else {
        $data = $r->fetch_assoc();
        $city_id = $data['id'];
        $q = "SELECT    `ad`.`id`,
                        `ad`.`date`,
                        (SELECT `name` FROM `city` WHERE `id` = `ad`.`city_id`) as `city`,
                        `ad`.`desc`,
                        `ad`.`price`,
                        (SELECT COUNT(`sales`.`id`) FROM `sales` LEFT JOIN `salesplan` ON `sales`.`salesplan_id`=`salesplan`.`id` 
                              WHERE DATE_ADD(`sales`.`date`,INTERVAL `salesplan`.`duration` DAY) >= NOW() AND `sales`.`ad_id`=`ad`.`id`) as `rank`
                    FROM `ad`
                    WHERE `city_id` = '$city_id' AND `desc` LIKE '%$keyword%' AND (ISNULL(`finished`) OR `finished` = '') AND (!ISNULL(`approved`) OR `approved` !='')
                    ORDER BY `rank` DESC, `date` DESC";
        $r = $conn->query($q);
        $result_text = "تعداد " . $r->num_rows . " آگهی یافت شد";
        $result_div = "";
        $ids = array();
        $i = 0;
        while ($data = $r->fetch_assoc()) {
            $ids[$i] = $data['id'];
            $pics = glob("uploads/p_" . $ids[$i] . "_*.*");
            $pics1 = (isset($pics[0])) ? $pics[0] . " alt='" . $data['desc'] . "'" : "''";
            $result_div .=
                "<div class='div_result'>
                <div class='div_result_top'>
                    <div class='div_desc'>
                        <label>" . $data['desc'] . "</label>" . '  ' . (($data['rank'] >= 1) ? '<span>ویژه</span>' : '') . "
                    </div> 
                    <label>" . p_date_mysql($data['date']) . "</label>
                    <label>" . $data['city'] . "</label>
                    <label>" . number_format($data['price'], 0) . " تومان</label>
                    <a href='ad_detail.php?q=" . $data['id'] . "'>جزئیات</a>
                </div>
                <div class='div_result_pic'>
                    <img src=$pics1/>
                </div>
            </div>";
            $i++;
        }
        $_SESSION['ids'] = $ids;

        // adding to impression field in ad table by one.
        if (empty($keyword) || !in_array($keyword, $_SESSION['search'])) {
            $q1 = join(',', $ids);
            $q2 = "UPDATE `ad` SET `impression`=`impression`+1 WHERE `ad`.`id` IN (" . $q1 . ")";
            $conn->query($q2);
            if(!empty($keyword)) {
                array_push($_SESSION['search'], $keyword);
            }
        }
        $conn->close();
    }
}

?>

<!DOCTYPE html>
<html lang="fa">
    <?php include "head.php" ?>
<body>
    <?php include "header.php" ?>
    <div class="cont01">
        <label><?php echo $result_text; ?></label>
    </div>
    <div class="cont01">
<!--    <label for="search">جستجو</label>
        <input type="text" id="search" name="search" placeholder="جستجو در آگهی ها">-->
        <div class='div_result_pc'>
            <?php echo $result_div; ?>
        </div>
        </div>
    </div>
</body>
</html>