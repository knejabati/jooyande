<?php session_start();
    if(isset($_SESSION['username'])){
        header("location: dex.php");
    }
    include_once "functions.php";
    include_once "../function/p_date.php";
    require_once "../function/kia_func.php";
?>
<!DOCTYPE html>
<html lang="fa" xmlns:btn="http://www.w3.org/1999/html">
    <?php include "head.php"; ?>
<body>
    <?php
        include "header.php";
    if ($_SERVER['REQUEST_METHOD'] == "POST") {
            if ( !isset($_POST['email']) || !isset($_POST['psw']) || !isset($_POST['phone']) || !isset($_POST['fname']) || !isset($_POST['lname'])) {
                echo '<p>لطفا اطلاعات را به صورت کامل پر کنید</p>';
            } else {
                $fname = $_POST['fname'];
                $lname = $_POST['lname'];
                $gender = ($_POST['gender'] == 'male') ? 'آقای' : 'خانم';
                $phone = $_POST['phone'];
                $user = $_POST['email'];
                $psw = inp_validate($_POST['psw']);
                $psw = password_hash($psw,1);
                $remember = $_POST['remember'];
                $conn = jooyande();
                $q = "insert into `user` (`fname`,`lname`,`gender`,`phone`,`email`,`psw`,`createdon`) values
                                      ('$fname','$lname','$gender','$phone','$user','$psw',NOW())";
                $r = $conn->query($q);
                if ($r == 0){
                    echo '<p>در ثبت اطلاعات خطایی ایجاد شده، لطفا مجددا امتحان نمایید</p><br/>';
                    echo '<p>' . $conn->error . '</p>';
                } else {
                    $user_id = $conn->insert_id;
                    set_user_session(array('id'=>$user_id, 'email'=>$user, 'gender'=>$gender, 'fname'=>$fname, 'lname'=>$lname, 'phone'=>$phone));
                    if($remember == "on") {
                       setcookie('username',$user,time() + 2592000,'/'); //30days
                    }
                    header('location: dex.php');
                 }
            }
        }
        ?>
    <div class="div_singup cont01">
        <form method="post" onsubmit="return check_signup()">
            <label for="fname" class="label_style">نام</label>
            <input class="Input_style" id="fname" name="fname" placeholder="لطفا نام خود را وارد نمایید" type="text" required title=""/><br/>
            <label for="lname" class="label_style">نام خانوادگی</label>
            <input class="Input_style" id="lname" name="lname" placeholder="لطفا نام خانوادگی خود را وارد نمایید"
                   type="text" required title=" "/><br/>
            <label for="gender" class="label_style">جنسیت</label>
            <div class="div_select">
                <input type="radio" name="gender" value="male" id="rdo_male"  checked/>
                <label for="rdo_male" class="label_style">آقا</label>
                <input type="radio" name="gender" value="female" id="rdo_female"/>
                <label for="rdo_female" class="label_style">خانم</label>
            </div><br/>
            <label for="phone" class="label_style">تلفن همراه</label>
            <input class="Input_style" id="phone" name="phone" placeholder="لطفا تلفن خود را وارد نمایید" type="text" required title=" "/><br/>
            <label for="email" class="label_style">آدرس ایمیل</label>
            <input class="Input_style" id="email" name="email" placeholder="لطفا آدرس ایمیل خود را وارد نمایید"
                   type="text" required title=" "/><br/>
            <label for="psw" class="label_style">کلمه عبور</label>
            <input class="Input_style" id="psw" name="psw" placeholder="لطفا کلمه عبود خود را وارد نمایید" type="password" required title=" "/><br/>
            <label for="re_psw" class="label_style">تکرار کلمه عبور</label>
            <input class="Input_style" id="re_psw" name="re_psw" placeholder="لطفا تکرار کلمه عبود خود را وارد نمایید" type="password" required title=" "/><br/>
            <input type="checkbox" name = "remember"/>
            <label id="remember" for="remember">مرا با خاطر داشته باش</label><br/>
            <button type="submit" id="btn_signup" class="btn">ثبت نام</button>
        </form>
    </div>
</body>
</html>