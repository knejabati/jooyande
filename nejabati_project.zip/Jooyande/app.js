var ar_city = [];
function check_signin() {
    if (document.getElementById("username").value === '') {
        window.alert("لطفا نام کاربری خود را وارد نمایید");
        return false;
    }
    if (document.getElementById("psw").value === '') {
        window.alert("لطفا کلمه عبور خود را وارد نمایید");
        return false;
    }
}
function check_signup() {
    if (document.getElementById("fname").value === '') {
        window.alert("لطفا نام کوچک خود را وارد نمایید");
        return false;
    }
    if (document.getElementById("lname").value === '') {
        window.alert("لطفا نام خانوادگی خود را وارد نمایید");
        return false;
    }
    if (document.getElementById("phone").value === '') {
        window.alert("لطفا شماره تلفن خود را وارد نمایید");
        return false;
    }
    if (document.getElementById("email").value ==='') {
        window.alert("لطفا آدرس ایمیل خود را وارد نمایید");
        return false;
    }
    if (document.getElementById("psw").value === '') {
        window.alert("لطفا کلمه عبور خود را وارد نمایید");
        return false;
    }
    if (document.getElementById("re_psw").value !== document.getElementById("psw").value) {
        window.alert("دو کلمه عبور وارده شده مغایر هستند");
        return false;
    }
}
function adding() {
    window.alert("لطفا ابتدا ثبت نام نمایید");
    return false;
}
function add_ad_check() {
    if (document.getElementById("city").value === '') {
        window.alert("لطفا نام شهر را وارد نمایید");
        return false;
    }
    if (document.getElementById("description").value === '') {
        window.alert("لطفا عنوان را وارد نمایید");
        return false;
    }
    if (document.getElementById("phone").value === '') {
        window.alert("لطفا شماره تلفن را وارد نمایید");
        return false;
    }
    if (isNaN(document.getElementById("price").value) || document.getElementById("price").value === '') {
        window.alert("لطفا مقداری عددی به تومان برای  قیمت وارد نمایید");
        return false;
    }
}
function p_select(father) {
    document.getElementById("select_province").value = father.innerText;
}
function get_city(father){
    let province = father.innerText;
    var x = new XMLHttpRequest();
    x.onreadystatechange = function(){
        if(x.readyState == 4 && x.status == 200){
            ar_city=JSON.parse(x.responseText);
            filter_op(document.getElementById('select_city'),ar_city,false);
        }
    }
    x.open("post","get_city.php",true);
    x.setRequestHeader("content-type","text/plain");
    x.send(province);
}
function check_search() {
    let city = document.getElementById('select_city').value;
    // let keyword = document.getElementById('inp_keyword').value;
    // if(city === "" || keyword === ""){
    if(city === ""){
        // window.alert("لطفا شهر و کلمه کلیدی را وارد نمایید");
        window.alert("لطفا شهر را وارد نمایید");
        return false;
    }
}
function navigate(father) {
    let id = father.dataset.id;
    if(!isNaN(id)) {
        location.href = ("ad_detail.php?q=" + id);
    }
}
function filter_ad(father){
    switch (father.value) {
        case '1':
            var i = 1;
            break;
        case '2':
            var i = 2;
            break;
        case '3':
            var i = 3;
            break;
        case '4':
            var i = 4;
            break;
        case '5':
            var i = 5;
            break;
        case '6':
            var i = 6;
            break;
    }
    x = new XMLHttpRequest();
    x.onreadystatechange = function(){
        if(x.readyState == 4 && x.status == 200){
            var result = JSON.parse(x.responseText);
            console.log(result);
            document.getElementById('my_tbody').innerHTML = result.thead;
            document.getElementById('links').innerHTML = result.p;
            document.getElementById('total').innerText = result.total;
        }
    }
    x.open("get","get_ad_list.php?key=" + i,true);
    x.send();
}
function next_ads(i){
    // this is for labels which brings more result in table
    var x = new XMLHttpRequest();
    x.onreadystatechange = function(){
        if(x.status == 200 && x.readyState == 4){
            var result = JSON.parse(x.responseText);
            document.getElementById('my_tbody').innerHTML = result.thead;
        }
    }
    x.open("get","get_ad_list.php?group=" + i,true);
    x.send();
}
function next_ad(){
    //this goes to next record in ads admin panel
    location.href = "admin_review.php?q=next";
}
function prev_ad() {
    //this goes to previous record in ads admin panel
    location.href = "admin_review.php?q=prev";
}
function go_to_ad(record) {
    location.href = "admin_review.php?q=go&r=" + record;
}
function verify_ad(action){
    if (action == "approve") {
        location.href = 'verify_ad.php?action=approve';
    } else if (action == "reject"){
        location.href = 'verify_ad.php?action=reject';
    }
}

