<?php
/**
 * Created by PhpStorm.
 * User: kiavash
 * Date: 5/9/2019
 * Time: 12:11 AM
 */
session_start();
include_once "functions.php";
include_once "../function/p_date.php";
if($_SERVER['REQUEST_METHOD'] == 'GET'){
    $conn = jooyande();
    $pointer = $_SESSION['pointer'];
    $id = $_SESSION['ad_list'][$pointer]['id'];
    if(isset($_GET['action'])){
        if($_GET['action'] == "approve"){
            $q = "UPDATE `ad` SET `approved` = NOW(), `rejected` = null  WHERE `id` = '$id'";
            if($conn->query($q) === TRUE) {
                $_SESSION['ad_list'][$pointer]['approved'] = date('y-m-d h:i:s');
                $_SESSION['ad_list'][$pointer]['rejected'] = null;
            } else {
                echo "un-successful, an error occurred";
                die();
            }
            header("location:admin_review.php");
        }
        if($_GET['action'] == "reject"){
            $q = "UPDATE `ad` SET `approved` = null, `rejected` = NOW() WHERE `id` = '$id'";
            if($conn->query($q) === TRUE) {
                $_SESSION['ad_list'][$pointer]['approved'] = null;
                $_SESSION['ad_list'][$pointer]['rejected'] = date('y-m-d h:i:s');
            }
            else {
                echo "un-successful, an error occurred";
                die();
            }
            header("location:admin_review.php");
        }
    }
}