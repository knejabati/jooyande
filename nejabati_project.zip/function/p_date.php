<?php
function p_date_mysql($mysql_time){
    if(is_null($mysql_time) || empty($mysql_time)){
        return null;
    } else {
        $myDate = strtotime($mysql_time);
        return p_date(date("y", $myDate), date("m", $myDate), date("d", $myDate));
    }
}

function p_date_php($php_time){
    if(is_null($php_time) || empty($php_time)){
        return null;
    } else {
        return p_date(date("y", $php_time), date("m", $php_time), date("d", $php_time));
    }
}


//changing persian date for a given georgian date
//if no parameter is sent gives the today date.
function p_date ($year = null, $month = null, $day = null){
    if (is_null($year) || is_null($month) || is_null($day) ){
        $year = date("y");
        $month = date("m");
        $day = date("d");
    }
    $now_ts = intval(mktime(24,0,0,$month,$day,$year) / (60*60*24));
    $reference_ts = intval(mktime(null,null,null,3,21,1973) / (60*60*24));
    $days = ($now_ts - $reference_ts);
    $kb_days = intdiv($days,1461); //1461 is 365+365+365+366 i.e total amount of days in four years
    $year = 1352 + intdiv(($days - $kb_days) , 365);
    $remain_days = $days - (($year - 1352) * 365) - $kb_days;
    $month = 1;
    $day = 1;

    switch (true){
        case ($remain_days > 336):
            $month = "12";
            $day = $remain_days - 336;
            break;
        case ($remain_days > 306):
            $month = "11";
            $day = $remain_days - 306;
            break;
        case ($remain_days > 276):
            $month = "10";
            $day = $remain_days - 276;
            break;
        case ($remain_days > 246):
            $month = "09";
            $day = $remain_days - 246;
            break;
        case ($remain_days > 216):
            $month = "08";
            $day = $remain_days - 216;
            break;
        case ($remain_days > 186):
            $month = "07";
            $day = $remain_days - 186;
            break;
        case ($remain_days > 155):
            $month = "06";
            $day = $remain_days - 155;
            break;
        case ($remain_days > 124):
            $month = "05";
            $day = $remain_days - 124;
            break;
        case ($remain_days > 94):
            $month = "04";
            $day = $remain_days - 94;
            break;
        case ($remain_days > 62):
            $month = "03";
            $day = $remain_days - 62;
            break;
        case ($remain_days > 31):
            $month = "02";
            $day = $remain_days - 31;
            break;
        case ($remain_days >= 1):
            $month = "01";
            $day = $remain_days;
            break;
    }
    $day = ($day <10 ? "0" . $day : $day);
    return $year . "/" . $month . "/" . $day;
}

//gives weekday of a given georgian date
//if no parameter is sent gives the today weekday.
function p_weekday ($year = null, $month = null, $day = null) {
    if (is_null($year) || is_null($month) || is_null($month) ){
        $year = date("y");
        $month = date("m");
        $day = date("d");
    }
    $weekday_e = mktime(null,null,null,$month,$day,$year);
    return date("l",$weekday_e);
}