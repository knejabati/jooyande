<?php
/**
 * Created by PhpStorm.
 * User: kiavash
 * Date: 4/27/2019
 * Time: 10:07 PM
 */
function inp_validate($inp){
    $inp = trim($inp);
    $inp = stripslashes($inp);
    $inp = htmlspecialchars($inp);
    return $inp;
}